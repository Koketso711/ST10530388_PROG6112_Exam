import javax.swing.*;
import java.awt.*;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class ProductApp extends JFrame {

    private JTextField txtCustomer;
    private JTextField txtPrice;
    private JComboBox<String> cmbProduct;

    public ProductApp() {

        setTitle("Product App");
        setSize(550, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Create menu bar
        JMenuBar menuBar = new JMenuBar();

        JMenu fileMenu = new JMenu("File");
        JMenu toolsMenu = new JMenu("Tools");

        JMenuItem exitItem = new JMenuItem("Exit");
        JMenuItem processItem = new JMenuItem("Process");
        JMenuItem clearItem = new JMenuItem("Clear");

        fileMenu.add(exitItem);
        toolsMenu.add(processItem);
        toolsMenu.add(clearItem);

        menuBar.add(fileMenu);
        menuBar.add(toolsMenu);

        setJMenuBar(menuBar);

        // Create form components
        JPanel panel = new JPanel(new GridLayout(4, 2, 10, 15));
        panel.setBorder(BorderFactory.createEmptyBorder(
                25, 25, 25, 25));

        JLabel lblCustomer = new JLabel("Customer Name:");
        txtCustomer = new JTextField();

        JLabel lblProduct = new JLabel("Select Product:");

        String[] products = {
            "Cozy Nights Monarch",
            "Restonic Barbados",
            "Sealy Phuket"
        };

        cmbProduct = new JComboBox<>(products);

        JLabel lblPrice = new JLabel("Enter Price:");
        txtPrice = new JTextField();

        JButton btnProcess = new JButton("PROCESS");

        panel.add(lblCustomer);
        panel.add(txtCustomer);

        panel.add(lblProduct);
        panel.add(cmbProduct);

        panel.add(lblPrice);
        panel.add(txtPrice);

        panel.add(new JLabel(""));
        panel.add(btnProcess);

        add(panel);

        // Process button
        btnProcess.addActionListener(e -> processSale());

        // Process menu item
        processItem.addActionListener(e -> processSale());

        // Clear menu item
        clearItem.addActionListener(e -> clearForm());

        // Exit menu item
        exitItem.addActionListener(e -> System.exit(0));
    }

    // Process customer sale
    private void processSale() {

        String customer = txtCustomer.getText().trim();
        String product = (String) cmbProduct.getSelectedItem();

        if (customer.isEmpty() || txtPrice.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Please enter all required information.");
            return;
        }

        try {

            double price = Double.parseDouble(txtPrice.getText());

            if (!Double.isFinite(price) || price <= 0) {
                JOptionPane.showMessageDialog(this,
                        "Please enter a valid price greater than zero.");
                return;
            }

            ProductCalculations calculation =
                    new ProductCalculations(price);

            double vat = calculation.GetVat();
            double commission = calculation.GetCommission();
            double total = calculation.GetTotal();

            // Display results
            String message =
                    "Customer Name: " + customer +
                    "\nProduct: " + product +
                    "\nVAT: R " + vat +
                    "\nCOMMISSION: R " + commission +
                    "\nTOTAL: R " + total;

            JOptionPane.showMessageDialog(this, message);

            // Save information to data.txt
            saveToFile(customer, product, vat, commission, total);

        } catch (NumberFormatException e) {

            JOptionPane.showMessageDialog(this,
                    "Please enter a valid numeric price.");

        }
    }

    // Save sales information
    private void saveToFile(String customer, String product,
            double vat, double commission, double total) {

        try (PrintWriter writer =
                new PrintWriter(new FileWriter("data.txt", true))) {

            writer.println("DATA LOG");
            writer.println("******************************");
            writer.println("Customer Name: " + customer);
            writer.println("Product: " + product);
            writer.println("VAT: R " + vat);
            writer.println("COMMISSION: R " + commission);
            writer.println("TOTAL: R " + total);
            writer.println("******************************");

        } catch (IOException e) {

            JOptionPane.showMessageDialog(this,
                    "Error saving data to file.");

        }
    }

    // Clear form information
    private void clearForm() {

        txtCustomer.setText("");
        txtPrice.setText("");
        cmbProduct.setSelectedIndex(0);
    }

    public static void main(String[] args) {

        SwingUtilities.invokeLater(() -> {
            new ProductApp().setVisible(true);
        });
    }
}