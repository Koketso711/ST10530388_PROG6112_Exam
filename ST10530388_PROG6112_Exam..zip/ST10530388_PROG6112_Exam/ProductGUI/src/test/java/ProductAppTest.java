import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ProductAppTest {

    // Unit Test 1
    @Test
    public void GetVat_WithValidData_ReturnsCorrectValue() {

        ProductCalculations product =
                new ProductCalculations(3500);

        double result = product.GetVat();

        assertEquals(525.0, result, 0.001);
    }

    // Unit Test 2
    @Test
    public void GetTotal_WithValidData_ReturnsCorrectValue() {

        ProductCalculations product =
                new ProductCalculations(3500);

        double result = product.GetTotal();

        assertEquals(4200.0, result, 0.001);
    }
}