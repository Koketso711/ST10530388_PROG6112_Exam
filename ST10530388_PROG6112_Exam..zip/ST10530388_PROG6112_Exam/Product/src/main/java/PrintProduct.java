
public class PrintProduct {

    private Product product;

    public PrintProduct(Product product) {

        this.product = product;
    }

    // Print total product sales
    public void PrintTotalSales() {

        System.out.println("\nPRODUCT SALES REPORT - 2026");

        System.out.println("----------------------------------------");

        System.out.println("TOTAL PRODUCT SALES: "
                + product.GetTotalProductsSold());
    }

    // Print average product sales
    public void PrintAverageSales() {

        System.out.println("AVERAGE PRODUCT SALES: "
                + product.GetAverageProductSold());
    }

    // Print most popular product
    public void PrintMostPopularProduct() {

        System.out.println("MOST POPULAR PRODUCT: "
                + product.GetMostPopularProduct());
    }
}