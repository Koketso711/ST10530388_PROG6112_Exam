import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        String[] productNames = {
            "Cozy Nights Monarch",
            "Restonic Barbados",
            "Sealy Phuket"
        };

        int[][] sales = new int[3][3];

        for (int i = 0; i < productNames.length; i++) {

            for (int j = 0; j < 3; j++) {

                System.out.print("Enter number of sales for month "
                        + (j + 1) + " for "
                        + productNames[i] + " mattress: ");

                sales[i][j] = input.nextInt();
            }
        }

        Product product = new Product(productNames, sales);

        PrintProduct report = new PrintProduct(product);

        report.PrintTotalSales();
        report.PrintAverageSales();
        report.PrintMostPopularProduct();

        input.close();
    }
}